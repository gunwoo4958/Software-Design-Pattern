package hansung.designpatterns.facade.hometheater;

public class LGDvdPlayerAdapter implements DvdPlayer {

    LGDvdPlayer dvd;

    public LGDvdPlayerAdapter(LGDvdPlayer dvd){
        this.dvd= dvd;
    }

    //LG디비디를 이용하여 구현하라 그 후 교체
    @Override
    public void on() {
        dvd.on();
    }

    @Override
    public void off() {
       dvd.off();
    }

    @Override
    public void eject() {
        dvd.eject();
    }

    @Override
    public void play(String movie) {
        dvd.play();
    }

    @Override
    public void play(int track) {

    }

    @Override
    public void stop() {
        dvd.stop();
    }

    @Override
    public void pause() {
        dvd.pause();
    }

    @Override
    public void setTwoChannelAudio() {
        dvd.setTwoChannelAudio();
    }

    @Override
    public void setSurroundAudio() {

    }
}
