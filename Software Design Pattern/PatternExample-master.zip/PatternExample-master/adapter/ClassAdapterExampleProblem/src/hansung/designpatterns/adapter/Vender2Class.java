package hansung.designpatterns.adapter;

public class Vender2Class {
	public void specificRequest() {
		System.out.println("A request is served");
	}
}
