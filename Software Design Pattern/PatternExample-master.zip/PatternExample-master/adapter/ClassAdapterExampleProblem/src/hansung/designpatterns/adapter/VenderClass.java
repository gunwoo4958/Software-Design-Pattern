package hansung.designpatterns.adapter;

public interface VenderClass {
	void request();
}
