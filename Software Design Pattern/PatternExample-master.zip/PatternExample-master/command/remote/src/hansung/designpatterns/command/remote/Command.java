package hansung.designpatterns.command.remote;

public interface Command {
	public void execute();
}
