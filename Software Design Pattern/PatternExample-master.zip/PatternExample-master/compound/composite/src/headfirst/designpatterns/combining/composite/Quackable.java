package headfirst.designpatterns.combining.composite;

public interface Quackable {
	public void quack();
}
