package hansung.designpatterns.decorator.starbuzzalternative;


public class StarbuzzCoffee {

}
