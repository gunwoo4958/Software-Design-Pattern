package hansung.designpatterns.factory.pizzaaf;


public interface Clams {
	public String toString();
}
