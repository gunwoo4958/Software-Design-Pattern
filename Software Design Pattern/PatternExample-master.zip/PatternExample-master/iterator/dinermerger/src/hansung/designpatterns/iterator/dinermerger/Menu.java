package hansung.designpatterns.iterator.dinermerger;

public interface Menu {
	public Iterator createIterator();
}
