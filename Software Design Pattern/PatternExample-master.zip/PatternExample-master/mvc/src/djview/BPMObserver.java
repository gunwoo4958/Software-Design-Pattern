package djview;


public interface BPMObserver {
	void updateBPM();
}
