package djview;


public interface BeatObserver  {
	void updateBeat();
}
