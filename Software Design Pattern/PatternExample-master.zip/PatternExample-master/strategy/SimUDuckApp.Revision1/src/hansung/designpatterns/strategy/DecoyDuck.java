package hansung.designpatterns.strategy;

public class DecoyDuck extends Duck {

	public void display() {
		System.out.println("I'm a duck Decoy");

	}

}
