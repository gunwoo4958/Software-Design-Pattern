package hansung.designpatterns.strategy;

public interface Flyable {
	public void fly();
}
