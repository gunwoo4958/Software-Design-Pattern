package hansung.designpatterns.strategy;

public interface Quackable {
	public void quack();
}
